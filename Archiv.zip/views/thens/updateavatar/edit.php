<label>
    <?= _("URL des neuen Avatars") ?>
    <input type="text" name="data[then_settings][avatar_url]" value="<?= htmlReady($hook['then_settings']['avatar_url']) ?>" placeholder="https://...">
</label>